"""
Modulo: n_reinas.py
Problema 1 - Vigilancia del Castillo (N-Reinas)

Resuelve el problema de las N-Reinas utilizando Backtracking.
Cada "guardia" (reina) vigila su fila, columna y diagonales,
por lo que no puede haber dos guardias que se observen entre si.
"""


def es_posicion_valida(columnas_reinas, fila, columna):
    """
    Verifica si es seguro colocar un guardia en (fila, columna),
    dado que los guardias en filas anteriores ya estan ubicados.
    """
    for fila_anterior in range(fila):
        columna_anterior = columnas_reinas[fila_anterior]

        # Misma columna -> se vigilan entre si
        if columna_anterior == columna:
            return False

        # Misma diagonal (principal o secundaria)
        if abs(columna_anterior - columna) == abs(fila_anterior - fila):
            return False

    return True


def backtrack_n_reinas(columnas_reinas, fila, n, soluciones):
    """
    Funcion recursiva de Backtracking. Intenta ubicar un guardia
    en cada fila del tablero, una fila a la vez.

    columnas_reinas[i] = columna donde esta el guardia de la fila i.
    """
    # Caso base: se colocaron guardias validos en todas las filas
    if fila == n:
        soluciones.append(columnas_reinas.copy())
        return

    for columna in range(n):
        if es_posicion_valida(columnas_reinas, fila, columna):
            columnas_reinas[fila] = columna            # Probar
            backtrack_n_reinas(columnas_reinas, fila + 1, n, soluciones)
            columnas_reinas[fila] = -1                  # Deshacer (backtrack)


def resolver_n_reinas(n):
    """
    Punto de entrada para resolver el problema de las N-Reinas.

    Retorna una lista con todas las soluciones encontradas. Cada solucion
    es una lista donde el indice representa la fila y el valor la columna
    en la que se ubica el guardia.
    """
    soluciones = []
    columnas_reinas = [-1] * n
    backtrack_n_reinas(columnas_reinas, 0, n, soluciones)
    return soluciones


def imprimir_tablero(solucion, n):
    """
    Representa visualmente una solucion del tablero N x N.
    Q = Guardia
    . = Casilla vacia
    """
    for fila in range(n):
        casillas = []
        for columna in range(n):
            if solucion[fila] == columna:
                casillas.append("Q")
            else:
                casillas.append(".")
        print(" ".join(casillas))


def solicitar_tamano_tablero():
    """
    Solicita al usuario el tamano N del tablero, validando que sea
    un entero positivo.
    """
    while True:
        entrada = input("Ingrese el tamano del tablero (N): ").strip()

        if not entrada.isdigit():
            print("Error: debe ingresar un numero entero positivo.")
            continue

        n = int(entrada)

        if n <= 0:
            print("Error: N debe ser mayor que 0.")
            continue

        if n > 12:
            confirmacion = input(
                f"N = {n} puede tardar bastante en calcular todas las "
                "soluciones. Desea continuar? (s/n): "
            ).strip().lower()
            if confirmacion != "s":
                continue

        return n


def ejecutar_n_reinas():
    """
    Flujo completo del Problema 1: solicita el tamano del tablero,
    resuelve el problema con Backtracking y muestra los resultados.
    """
    n = solicitar_tamano_tablero()
    soluciones = resolver_n_reinas(n)

    print(f"\n--- Vigilancia del Castillo (N = {n}) ---\n")

    if len(soluciones) == 0:
        print("No existe ninguna solucion valida para este tamano de tablero.")
    else:
        print("Una solucion valida encontrada:\n")
        imprimir_tablero(soluciones[0], n)

    print(f"\nCantidad total de soluciones encontradas: {len(soluciones)}")
