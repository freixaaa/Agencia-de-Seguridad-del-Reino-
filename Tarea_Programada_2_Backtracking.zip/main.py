"""
Tarea Programada 2: Agencia de Seguridad del Reino
Universidad LEAD

Programa principal con menu interactivo.

Problema 1: Vigilancia del Castillo (N-Reinas)
Problema 2: Gestion de Recursos del Reino (Suma de Subconjuntos)

Ambos problemas se resuelven utilizando la tecnica de Backtracking,
implementada manualmente sin librerias externas.
"""

from n_reinas import ejecutar_n_reinas
from subconjuntos import ejecutar_subconjuntos


def mostrar_menu():
    print("\n========================================")
    print(" Agencia de Seguridad del Reino - Hyrule")
    print("========================================")
    print("1. Vigilancia del Castillo (N-Reinas)")
    print("2. Gestion de Recursos del Reino (Subconjuntos)")
    print("3. Salir")


def main():
    while True:
        mostrar_menu()
        opcion = input("Seleccione una opcion: ").strip()

        if opcion == "1":
            ejecutar_n_reinas()
        elif opcion == "2":
            ejecutar_subconjuntos()
        elif opcion == "3":
            print("\nSaliendo del programa. Hasta la proxima, guardia real!")
            break
        else:
            print("\nOpcion invalida. Por favor seleccione 1, 2 o 3.")


if __name__ == "__main__":
    main()
